<h2>Wgraj plik aby przekonwertować go do base 64</h2>

<form method="POST" action="/base64/convert" enctype="multipart/form-data"  >
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="type" value="code">
    <input type="file" name="fileinput" id="fileinput" />
    <button type="send">Wgraj</button>
</form>

<h2>Wgraj plik aby rozkodować</h2>

<form method="POST" action="/base64/convert" enctype="multipart/form-data"  >
    <?php echo e(csrf_field()); ?>

    <input type="hidden"  name="type" value="decode">
    <input type="file" name="fileinput" id="fileinput" />
    <button type="send">Wgraj</button>
</form>

<h2>Pliki zakodowane</h2>
<ul>

<?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(($data != "." ) AND ($data !="..")): ?>
        <li><a target="_blank" href="/files/<?php echo e($data); ?>"><?php echo e($data); ?></a></li>
        <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>


<h2>Pliki odkodowane</h2>
<ul>

    <?php $__currentLoopData = $files2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(($data != "." ) AND ($data !="..")): ?>
            <li><a target="_blank" href="/files_enc/<?php echo e($data); ?>"><?php echo e($data); ?></a></li>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>